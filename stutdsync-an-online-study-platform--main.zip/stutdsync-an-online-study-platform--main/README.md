# stutdsync-an-online-study-platform-
Designed and developed the frontend of an interactive study platform aimed at helping students access learning materials, track progress, and engage with educational content. The platform features a clean, user-friendly interface with intuitive navigation and responsive design.
